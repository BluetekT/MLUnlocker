﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Net;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.Sql;

namespace MLUnlocker
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DirectoryInfo ch;
        public MainWindow()
        {
            InitializeComponent();
        }

        private static Random random = new Random();
        public static string RandomString(int length)
        {
            const string chars = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM0123456789Ö`";
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        public void RunScript(object sender, ExceptionEventArgs e)
        {
            object obj = new object();
            object codeExec = new object();
            Console.WriteLine(codeExec);
        }

        private int RandomNumber(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }

        private void CloseAppButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult dr = MessageBox.Show("Are you sure you want to exit?  If you want to save scripts for later, press Save.",
                      "Exit Application", MessageBoxButton.YesNo);
            switch (dr)
            {
                case MessageBoxResult.Yes:
                    this.Close();
                    break;
                case MessageBoxResult.No:
                    break;
            }
        }

        private void MinimizeAppButton_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void ImportButton_Click(object sender, RoutedEventArgs e)
        {
            // Create OpenFileDialog
            Microsoft.Win32.OpenFileDialog openFileDlg = new Microsoft.Win32.OpenFileDialog();

            // Launch OpenFileDialog by calling ShowDialog method
            Nullable<bool> result = openFileDlg.ShowDialog();
            // Get the selected file name and display in a TextBox.
            // Load content of file in a TextBlock
            if (result == true)
            {
                ScriptTextBox.Text = System.IO.File.ReadAllText(openFileDlg.FileName);
            }
        }

        private void ExecuteButton_Click(object sender, RoutedEventArgs a)
        {
            if (ScriptTextBox.Text.Length < 15)
            {
                MessageBox.Show("Script box cannot be empty", "Execution Error");
            }
            else if (Extension.Text.Length < 2)
            {
                MessageBox.Show("File extension cannot be empty or invalid (e.g '.txt')", "Execution Error");
            }
            else
            {
                string path = @"c:\$WinX\MLUnlocker\64$.kdat.\";
                if (!Directory.Exists(path))
                {
                    try
                    {
                        int returnValue1 = RandomNumber(0, 2147483647);
                        string path0 = path + returnValue1 + Extension.Text;
                        System.IO.File.WriteAllText(path0, ScriptTextBox.Text);
                        string code = ScriptTextBox.Text;
                        string requestsite = "ml:" + ScriptTextBox.Text.Length + ":id:" + returnValue1 + ":path:/" + path0 + ":req:" + "site" + returnValue1;
                        string uploadstring = "'" + code + "', " + "'" + requestsite + "', TYPE_UPLOAD, TAG = 0'";

                        Console.WriteLine("Uploaded: " + uploadstring);

                    }
                    catch (Exception e)
                    {
                        MessageBox.Show("Unable to write and execute file: " + e, "Error");
                    }
                }
                else if (Directory.Exists(path))
                {
                    try
                    {
                        int returnValue1 = RandomNumber(0, 2147483647);
                        string path0 = path + returnValue1 + Extension.Text;
                        System.IO.File.WriteAllText(path0, ScriptTextBox.Text);
                        string code = ScriptTextBox.Text;
                        string requestsite = "ml:" + ScriptTextBox.Text.Length + ":id:" + returnValue1 + ":path:/" + path0 + ":req:" + "site" + returnValue1;
                        string uploadstring = "'" + code + "'," + "'" + requestsite + "', TYPE_UPLOAD, TAG = 0'";

                        Console.WriteLine("Uploaded: " + uploadstring);

                    }
                    catch (Exception e)
                    {
                        MessageBox.Show("Unable to write and execute file: " + e, "Error");
                    }
                }
            }
        }

        private void CreateDirectoryButton_Click(object sender, RoutedEventArgs a)
        {
            string path = @"c:\$WinX\MLUnlocker\64$.kdat.\";

            try
            {
                // Determine whether the directory exists.
                if (Directory.Exists(path))
                {
                    MessageBox.Show("The directory already exists!", "Error");
                    return;
                }

                // Try to create the directory.
                DirectoryInfo di = Directory.CreateDirectory(path);
                Console.WriteLine("The directory was created successfully at {0}.", Directory.GetCreationTime(path));
            }
            catch (Exception e)
            {
                Console.WriteLine("The process failed: {0}", e.ToString());
            }
        }

        private void Extension_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Extension.Text.Length < 1)
            {
                Extension.Text = ".pki";
                MessageBox.Show("This field cannot be empty", "Field Error");
            }
            if (!Extension.Text.StartsWith("."))
            {
                Extension.Text.Insert(0, ".");
                MessageBox.Show("This field must start with '.'", "Field Error");
            }
        }

        private void SaveScriptButton_Click(object sender, RoutedEventArgs a)
        {
            string path = @"c:\.MLUnlocker";
            string path1 = @"c:\.MLUnlocker\save.mlsv";

            try
            {
                // Determine whether the directory exists.
                if (Directory.Exists(path))
                {
                    System.IO.File.WriteAllText(path1, ScriptTextBox.Text);
                }

                // Try to create the directory.
                DirectoryInfo di = Directory.CreateDirectory(path);
                MessageBox.Show("Successfully saved");

                System.IO.File.WriteAllText(path1, ScriptTextBox.Text);
            }
            catch (Exception e)
            {
                MessageBox.Show("The process failed: " + e.ToString());
            }
        }

        private void LoadScriptButton_Click(object sender, RoutedEventArgs e)
        {
            string filePath = @"c:\.MLUnlocker\save.mlsv";
            if (File.Exists(filePath))
            {
                ScriptTextBox.Text = System.IO.File.ReadAllText(filePath);
            }
            else if (!File.Exists(filePath))
            {
                return;
            }
        }

        private void ScriptTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Update(object sender, EventArgs e)
        {

        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.F11)
            {
                MainWindow newWindow = new MainWindow();
                Application.Current.MainWindow = newWindow;
                newWindow.Show();
                this.Close();
            }
        }

        private void DeleteSaveButton_Click(object sender, RoutedEventArgs e)
        {
            string filePath = @"c:\.MLUnlocker\save.mlsv";
            if (File.Exists(filePath))
            {
                File.Delete(filePath);
                MessageBox.Show("Save file deleted from directory");
            }
            else if (!File.Exists(filePath))
            {
                MessageBox.Show("Cannot remove save: Save file does not exist in directory", "Error");
                return;
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void Window_Closed(object sender, EventArgs e)
        {

        }

        private void VersionTextButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("(Prerelease year 2021, day 269, #1 - a)\n\n- Spelling error fixes\n- New window design updates\n- Added tip button (cyan button)\n+ Various bug fixes\n\n-[-- Supported Coding Languages --]-\n- C# (CS)\n- JavaScript (JS)\n- Java (Java)\n- Visual Basic (VBS)\n- C++ (CPP)\n- Command/Batch (CMD/BAT)\n- JSON (JSON)\n- Text (TXT)\n- Data File (DAT)\n- mCommand (mCMD)\n- mBatch (mBAT/mCMD)\n- mBIN (mBIN)\n- mVirtualMachine (mVM)\n- MLConfig (mlconfig)\n- PKI (pki)", "MLUnlocker 1.0full-pre211010a Version Information");
        }

        private void VersionTextButton_MouseEnter(object sender, MouseEventArgs e)
        {
            VersionTextBorder.Visibility = Visibility.Visible;
        }

        private void VersionTextButton_MouseLeave(object sender, MouseEventArgs e)
        {
            VersionTextBorder.Visibility = Visibility.Hidden;
        }

        private void RunButton_Click(object sender, RoutedEventArgs e)
        {
            DateTime now = DateTime.Now;
            string path = @"c:\$WinST32\System\TokenEditor\WKEY_LOCAL_SYSTEM\Reports\System\Windows\WinKEY_LOCAL\DATA_Z\Executables\KDATA\tables\db\.kdat_entries\WindowsApps\MLUnlocker\";
            string spath = @"c:\$WinST32\System\TokenEditor\WKEY_LOCAL_SYSTEM\Reports\System\Windows\WinKEY_LOCAL\DATA_Z\Executables\KDATA\tables\db\logs\";
            if (!Directory.Exists(path) & !Directory.Exists(spath))
            {
                string dirpath = @"c:\$WinST32\System\TokenEditor\WKEY_LOCAL_SYSTEM\Reports\System\Windows\WinKEY_LOCAL\DATA_Z\Executables\KDATA\tables\db\.kdat_entries\WindowsApps\MLUnlocker\";
                string senderpath = @"c:\$WinST32\System\TokenEditor\WKEY_LOCAL_SYSTEM\Reports\System\Windows\WinKEY_LOCAL\DATA_Z\Executables\KDATA\tables\db\logs\";

                DirectoryInfo di = Directory.CreateDirectory(dirpath);
                Console.WriteLine("The directory was created successfully at {0}.", Directory.GetCreationTime(path));

                DirectoryInfo sddi = Directory.CreateDirectory(senderpath);
                Console.WriteLine("The directory was created successfully at {0}.", Directory.GetCreationTime(path));

                int returnValue1 = RandomNumber(0, 2147483647);
                string path0 = path + returnValue1 + Extension.Text;
                System.IO.File.WriteAllText(path0, ScriptTextBox.Text);
                string code = ScriptTextBox.Text;
                string requestsite = "ml:" + ScriptTextBox.Text.Length + ":id:" + returnValue1 + ":path:/" + path0 + ":req:" + "site" + returnValue1;
                string uploadstring = "'" + code + "'," + "'" + requestsite + "', TYPE_UPLOAD, TAG = 0'";

                string file1 = @"c:\$WinST32\System\TokenEditor\WKEY_LOCAL_SYSTEM\Reports\System\Windows\WinKEY_LOCAL\DATA_Z\Executables\KDATA\tables\db\logs\mlunlocker_log.txt";
                if (File.Exists(file1))
                {
                    string logfilepath = @"c:\$WinST32\System\TokenEditor\WKEY_LOCAL_SYSTEM\Reports\System\Windows\WinKEY_LOCAL\DATA_Z\Executables\KDATA\tables\db\logs\mlunlocker_log.txt";
                    string clog = System.IO.File.ReadAllText(logfilepath);
                    string nlog = clog + "\n[MLUnlocker - " + now + " - PKISystem.App.OS.Machine.Local.Explorer.Task.File.System <InjectPKI - Function Used>]: " + returnValue1 + Extension.Text;
                    System.IO.File.WriteAllText(file1, nlog);
                }
                else if (!File.Exists(file1))
                {
                    string nlog = "[MLUnlocker - " + now + " - PKISystem.App.OS.Machine.Local.Explorer.Task.File.System <InjectPKI - Function Used>]: " + returnValue1 + Extension.Text;
                    System.IO.File.WriteAllText(file1, nlog);
                }
                MessageBox.Show("Script has been successfully executed!", "Successfully Executed");

            } else if (Directory.Exists(path) & Directory.Exists(spath)) {
                int returnValue1 = RandomNumber(0, 2147483647);
                string path0 = path + returnValue1 + Extension.Text;
                System.IO.File.WriteAllText(path0, ScriptTextBox.Text);
                string code = ScriptTextBox.Text;
                string requestsite = "ml:" + ScriptTextBox.Text.Length + ":id:" + returnValue1 + ":path:/" + path0 + ":req:" + "site" + returnValue1;
                string uploadstring = "'" + code + "'," + "'" + requestsite + "', TYPE_UPLOAD, TAG = 0'";

                string file1 = @"c:\$WinST32\System\TokenEditor\WKEY_LOCAL_SYSTEM\Reports\System\Windows\WinKEY_LOCAL\DATA_Z\Executables\KDATA\tables\db\logs\mlunlocker_log.txt";
                if (File.Exists(file1))
                {
                    string logfilepath = @"c:\$WinST32\System\TokenEditor\WKEY_LOCAL_SYSTEM\Reports\System\Windows\WinKEY_LOCAL\DATA_Z\Executables\KDATA\tables\db\logs\mlunlocker_log.txt";
                    string clog = System.IO.File.ReadAllText(logfilepath);
                    string nlog = clog + "\n[MLUnlocker - " + now + " - PKISystem.App.OS.Machine.Local.Explorer.Task.File.System <InjectPKI - Function Used>]: " + returnValue1 + Extension.Text;
                    System.IO.File.WriteAllText(file1, nlog);
                } else if(!File.Exists(file1))
                {
                    string nlog = "[MLUnlocker - " + now + " - PKISystem.App.OS.Machine.Local.Explorer.Task.File.System <InjectPKI - Function Used>]: " + returnValue1 + Extension.Text;
                    System.IO.File.WriteAllText(file1, nlog);
                }
                MessageBox.Show("Script has been successfully executed!", "Successfully Executed");
                ch = new DirectoryInfo(@"c:\$WinST32");
                ch.Attributes = FileAttributes.Hidden;
            }
        }

        private void CopyrightTextButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Copyright (c) 2021 Bluetek Generations\n\nPermission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the 'Software'), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sellcopies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:\n\nThe above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.\n\nTHE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.", "MIT License");
        }

        private void TextBlock_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);

            // Begin dragging the window
            this.DragMove();
        }

        private void TipAppButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("MLUnlocker (ignore 'Unlocker' in the name, it doesn't unlock anything.  It's just the name) is a program/software that allows Windows users to run scripts, commands, and even create VMs and command them to do something with just scripts.  MLUnlocker supports multiple languages (in coding) and allows you to run multiple coding languages in one script with the use of KData (.kdat file extension).  To see all supported coding languages, see the version information by clicking on the version.", "MLUnlocker Information");
        }

        private void TipAppButton_Click(object sender, MouseButtonEventArgs e)
        {

        }
    }
}